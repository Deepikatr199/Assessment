package java_assignment;

import java.util.Scanner;

public class GameStorePurchase {
public static void main(String[] args) {
	int CalCost=0,speedCost=0,mysteryCost=0,pixelCost=0,puzzleCost=0;
	while(true) {
	System.out.println(" 1.Call of Warfare\n 2.Speed Racers\n 3.Mystery Mansion \n 4.Pixel Adventure\n 5.Puzzle Mania \n 6.Exit");
    Scanner scanner=new Scanner(System.in);
    int ch=scanner.nextInt();
    
    switch(ch) {
    
    case 1:{
    	System.out.println("enter how many copies you want to purchase");
    
	int copy=scanner.nextInt();
	System.out.println("Call of Warface is added"+copy);
	CalCost=copy*1500;
	break;
	
    }
	case 2:{
		System.out.println("enter how many copies you want to purchase");
	int copy=scanner.nextInt();
	System.out.println("Speed Racers  is added"+copy);
	
	speedCost=copy*1200;
	break;
    
    }
   case 3:{
	   System.out.println("enter how many copies you want to purchase");
   
   int copy=scanner.nextInt();
    System.out.println("Mystery Mansion is added"+copy);
    mysteryCost=copy*1100;
    break;
   }
   case 4:{
	   System.out.println("enter how many copies you want to purchase");
	   
	   int copy=scanner.nextInt();
	    System.out.println( "Pixel Adventure  is added"+copy);
	    pixelCost=copy*800;
	    break;
	   }
   case 5:{
	   System.out.println("enter how many copies you want to purchase");
	   
	   int copy=scanner.nextInt();
	    System.out.println("Puzzle Mania is added"+copy);
	    puzzleCost=copy*500;
	    break;
	   }
   case 6:{
       System.exit(0);
	   }
   
   }
   
   int totalCost=CalCost+speedCost+mysteryCost+pixelCost+puzzleCost;
	  System.out.println("total cost is "+totalCost);
   }

}
}

