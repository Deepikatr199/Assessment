package java_assignment;

import java.util.Scanner;

public class PalindromeNum {
public static void main(String[] args) {
	System.out.println("enter number");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
	int num=n;
	
	int reverse=0;
	while(n!=0) {
		int remainder=n%10;
		reverse=reverse*10+remainder;
		n=n/10;
		
	}
	
	if(num==reverse) {
		System.out.println("Palindrome");
	}
	else {
		System.out.println("Not Palindrome");
	}
}
}
